import React, { useState, useCallback } from 'react';
import { Upload, FileText, X, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';
import { BankStatement, SpendingAnalysis } from '../types';

interface BankStatementUploadProps {
  onAnalysisComplete: (analysis: SpendingAnalysis) => void;
}

const BankStatementUpload: React.FC<BankStatementUploadProps> = ({ onAnalysisComplete }) => {
  const [statements, setStatements] = useState<BankStatement[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<SpendingAnalysis | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      handleFiles(files);
    }
  };

  const handleFiles = (files: File[]) => {
    if (statements.length + files.length > 6) {
      alert('You can upload a maximum of 6 bank statements');
      return;
    }

    const newStatements: BankStatement[] = files.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      fileName: file.name,
      fileSize: file.size,
      uploadDate: new Date(),
      month: new Date().toLocaleString('default', { month: 'long' }),
      year: new Date().getFullYear(),
      status: 'processing'
    }));

    setStatements(prev => [...prev, ...newStatements]);

    // Simulate processing
    setTimeout(() => {
      setStatements(prev => 
        prev.map(stmt => 
          newStatements.some(ns => ns.id === stmt.id) 
            ? { ...stmt, status: 'completed' }
            : stmt
        )
      );
    }, 2000);
  };

  const removeStatement = (id: string) => {
    setStatements(prev => prev.filter(stmt => stmt.id !== id));
  };

  const analyzeSpending = () => {
    if (statements.length === 0) return;
    
    setIsAnalyzing(true);
    
    // Simulate spending analysis
    setTimeout(() => {
      const mockAnalysis: SpendingAnalysis = {
        totalSpending: 4250.75,
        categories: {
          dining: 850.25,
          groceries: 650.50,
          gas: 320.75,
          travel: 1200.00,
          shopping: 780.25,
          utilities: 249.00,
          other: 200.00
        },
        averageMonthlySpend: 4250.75 / statements.length,
        topCategories: ['Travel', 'Dining', 'Shopping'],
        recommendedCards: ['chase-sapphire-preferred', 'amex-platinum', 'citi-double-cash']
      };
      
      setAnalysis(mockAnalysis);
      setIsAnalyzing(false);
      onAnalysisComplete(mockAnalysis);
    }, 3000);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 mb-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-navy-700 mb-2 flex items-center">
          <TrendingUp className="mr-2" size={24} />
          Personalized Card Recommendations
        </h2>
        <p className="text-gray-600">
          Upload your bank statements to get personalized credit card recommendations based on your spending patterns.
        </p>
      </div>

      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
          isDragOver 
            ? 'border-amber-400 bg-amber-50' 
            : 'border-gray-300 hover:border-amber-300'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <Upload className="mx-auto mb-4 text-gray-400" size={48} />
        <h3 className="text-lg font-medium text-gray-700 mb-2">
          Upload Bank Statements
        </h3>
        <p className="text-gray-500 mb-4">
          Drag and drop your PDF bank statements here, or click to browse
        </p>
        <p className="text-sm text-gray-400 mb-4">
          Upload up to 6 months of statements (PDF format, max 10MB each)
        </p>
        
        <input
          type="file"
          multiple
          accept=".pdf"
          onChange={handleFileInput}
          className="hidden"
          id="bank-statement-upload"
        />
        <label
          htmlFor="bank-statement-upload"
          className="inline-block bg-amber-500 hover:bg-amber-600 text-white py-2 px-6 rounded-lg cursor-pointer transition-colors"
        >
          Choose Files
        </label>
      </div>

      {/* Uploaded Files */}
      {statements.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-medium text-gray-700 mb-4">
            Uploaded Statements ({statements.length}/6)
          </h3>
          <div className="space-y-3">
            {statements.map(statement => (
              <div key={statement.id} className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center">
                  <FileText className="mr-3 text-gray-400" size={20} />
                  <div>
                    <p className="font-medium text-gray-700">{statement.fileName}</p>
                    <p className="text-sm text-gray-500">
                      {formatFileSize(statement.fileSize)} • {statement.month} {statement.year}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {statement.status === 'processing' && (
                    <div className="flex items-center text-amber-600">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-amber-600 mr-2"></div>
                      Processing...
                    </div>
                  )}
                  {statement.status === 'completed' && (
                    <div className="flex items-center text-green-600">
                      <CheckCircle size={16} className="mr-1" />
                      Ready
                    </div>
                  )}
                  {statement.status === 'error' && (
                    <div className="flex items-center text-red-600">
                      <AlertCircle size={16} className="mr-1" />
                      Error
                    </div>
                  )}
                  
                  <button
                    onClick={() => removeStatement(statement.id)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Analyze Button */}
      {statements.length > 0 && statements.every(s => s.status === 'completed') && (
        <div className="mt-6 text-center">
          <button
            onClick={analyzeSpending}
            disabled={isAnalyzing}
            className="bg-navy-600 hover:bg-navy-700 disabled:bg-gray-400 text-white py-3 px-8 rounded-lg font-medium transition-colors"
          >
            {isAnalyzing ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Analyzing Spending Patterns...
              </div>
            ) : (
              'Analyze My Spending'
            )}
          </button>
        </div>
      )}

      {/* Analysis Results */}
      {analysis && (
        <div className="mt-8 bg-gradient-to-r from-amber-50 to-navy-50 p-6 rounded-lg border border-amber-200">
          <h3 className="text-xl font-bold text-navy-700 mb-4">Your Spending Analysis</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-gray-700 mb-3">Monthly Spending Breakdown</h4>
              <div className="space-y-2">
                {Object.entries(analysis.categories).map(([category, amount]) => (
                  <div key={category} className="flex justify-between items-center">
                    <span className="capitalize text-gray-600">{category}</span>
                    <span className="font-medium">${amount.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-700 mb-3">Key Insights</h4>
              <div className="space-y-2">
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Average Monthly Spend:</span> ${analysis.averageMonthlySpend.toFixed(2)}
                </p>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Top Categories:</span> {analysis.topCategories.join(', ')}
                </p>
                <p className="text-sm text-gray-600">
                  <span className="font-medium">Total Analyzed:</span> ${analysis.totalSpending.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
          
          <div className="mt-4 p-4 bg-white rounded-lg">
            <p className="text-sm text-navy-600 font-medium">
              💡 Based on your spending patterns, we've highlighted the best cards for you below!
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default BankStatementUpload;