import React from 'react';
import { CreditCard } from '../types';

interface CreditCardItemProps {
  card: CreditCard;
  onClick: (card: CreditCard) => void;
  isSelected?: boolean;
  isRecommended?: boolean;
}

const CreditCardItem: React.FC<CreditCardItemProps> = ({ 
  card, 
  onClick, 
  isSelected = false, 
  isRecommended = false 
}) => {
  return (
    <div 
      className={`
        bg-white rounded-xl shadow-md overflow-hidden transform transition-all duration-300
        hover:shadow-lg hover:-translate-y-1 cursor-pointer
        ${isSelected ? 'ring-2 ring-amber-400 shadow-amber-100' : ''}
        ${isRecommended ? 'ring-2 ring-green-400 shadow-green-100' : ''}
      `}
      onClick={() => onClick(card)}
    >
      <div className="h-48 relative overflow-hidden">
        {isRecommended && (
          <div className="absolute top-2 left-2 z-10">
            <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              Recommended
            </span>
          </div>
        )}
        <img 
          src={card.imageUrl} 
          alt={`${card.issuer} ${card.name} credit card`} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4 text-white">
          <span className="inline-block bg-amber-500 text-xs font-semibold px-2 py-1 rounded-full mb-2">
            {card.category}
          </span>
          <h3 className="text-xl font-bold">{card.issuer} {card.name}</h3>
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex justify-between items-center mb-3">
          <div>
            <span className="text-sm text-gray-500">Annual Fee</span>
            <p className="font-medium">{card.annualFee === 0 ? 'No Fee' : `$${card.annualFee}`}</p>
          </div>
          <div>
            <span className="text-sm text-gray-500">Required Credit</span>
            <p className="font-medium">{card.creditScoreRequired}</p>
          </div>
        </div>
        
        <div className="mb-3">
          <span className="text-sm text-gray-500">Rewards</span>
          <p className="font-medium">{card.rewardsRate}</p>
        </div>
        
        {card.signupBonus && (
          <div className="mb-3 bg-amber-50 p-2 rounded-md border border-amber-100">
            <span className="text-sm font-medium text-amber-700">Bonus: {card.signupBonus}</span>
          </div>
        )}
        
        <div className="mt-4 text-center">
          <button className="bg-navy-600 hover:bg-navy-700 text-white py-2 px-4 rounded-lg w-full transition-colors">
            View Details
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreditCardItem;