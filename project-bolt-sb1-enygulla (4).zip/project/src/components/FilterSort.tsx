import React from 'react';
import { FilterOptions, SortOption } from '../types';

interface FilterSortProps {
  filters: FilterOptions;
  setFilters: React.Dispatch<React.SetStateAction<FilterOptions>>;
  sortOption: SortOption;
  setSortOption: React.Dispatch<React.SetStateAction<SortOption>>;
}

const FilterSort: React.FC<FilterSortProps> = ({ 
  filters, 
  setFilters, 
  sortOption, 
  setSortOption 
}) => {
  const sortOptions: SortOption[] = [
    { label: 'Annual Fee (Low to High)', value: 'annualFee', direction: 'asc' },
    { label: 'Annual Fee (High to Low)', value: 'annualFee', direction: 'desc' },
    { label: 'APR (Low to High)', value: 'regularAPR', direction: 'asc' },
    { label: 'Rewards (High to Low)', value: 'rewardsRate', direction: 'desc' },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mb-6">
      <h2 className="text-xl font-semibold mb-4">Filter & Sort</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {/* Annual Fee Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Annual Fee
          </label>
          <select
            value={filters.annualFee}
            onChange={(e) => setFilters({...filters, annualFee: e.target.value as any})}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-amber-300 focus:ring focus:ring-amber-200 focus:ring-opacity-50"
          >
            <option value="all">All Fees</option>
            <option value="no-fee">No Annual Fee</option>
            <option value="under-100">Under $100</option>
            <option value="100-plus">$100+</option>
          </select>
        </div>
        
        {/* Credit Score Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Credit Score Needed
          </label>
          <select
            value={filters.creditScore}
            onChange={(e) => setFilters({...filters, creditScore: e.target.value as any})}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-amber-300 focus:ring focus:ring-amber-200 focus:ring-opacity-50"
          >
            <option value="all">Any Credit Score</option>
            <option value="excellent">Excellent</option>
            <option value="good">Good</option>
            <option value="fair">Fair</option>
            <option value="poor">Poor</option>
          </select>
        </div>
        
        {/* Card Category Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Card Category
          </label>
          <select
            value={filters.category}
            onChange={(e) => setFilters({...filters, category: e.target.value as any})}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-amber-300 focus:ring focus:ring-amber-200 focus:ring-opacity-50"
          >
            <option value="all">All Categories</option>
            <option value="cashback">Cash Back</option>
            <option value="travel">Travel</option>
            <option value="business">Business</option>
            <option value="student">Student</option>
            <option value="secured">Secured</option>
          </select>
        </div>
        
        {/* Sort Options */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Sort By
          </label>
          <select
            value={`${sortOption.value}-${sortOption.direction}`}
            onChange={(e) => {
              const [value, direction] = e.target.value.split('-');
              const newOption = sortOptions.find(
                opt => opt.value === value && opt.direction === direction
              );
              if (newOption) {
                setSortOption(newOption);
              }
            }}
            className="w-full rounded-lg border-gray-300 shadow-sm focus:border-amber-300 focus:ring focus:ring-amber-200 focus:ring-opacity-50"
          >
            {sortOptions.map((option) => (
              <option 
                key={`${option.value}-${option.direction}`}
                value={`${option.value}-${option.direction}`}
              >
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      {/* Reset Filters Button */}
      <div className="mt-4 text-right">
        <button
          onClick={() => {
            setFilters({
              annualFee: 'all',
              creditScore: 'all',
              category: 'all'
            });
            setSortOption(sortOptions[0]);
          }}
          className="text-sm text-gray-600 hover:text-gray-900 underline"
        >
          Reset Filters
        </button>
      </div>
    </div>
  );
};

export default FilterSort;