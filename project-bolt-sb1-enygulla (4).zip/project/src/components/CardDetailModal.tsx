import React from 'react';
import { CreditCard } from '../types';
import { X, CreditCard as CreditCardIcon, DollarSign, Percent, Award } from 'lucide-react';

interface CardDetailModalProps {
  card: CreditCard | null;
  onClose: () => void;
  onAddToComparison: (card: CreditCard) => void;
  isInComparison: boolean;
}

const CardDetailModal: React.FC<CardDetailModalProps> = ({ 
  card, 
  onClose, 
  onAddToComparison,
  isInComparison
}) => {
  if (!card) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div className="fixed inset-0 transition-opacity" aria-hidden="true">
          <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>

        <div 
          className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-2xl sm:w-full"
          role="dialog" 
          aria-modal="true" 
          aria-labelledby="modal-headline"
        >
          <div className="relative">
            <div className="h-48 w-full overflow-hidden">
              <img 
                src={card.imageUrl} 
                alt={`${card.issuer} ${card.name}`} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent">
                <div className="absolute top-4 right-4">
                  <button
                    onClick={onClose}
                    className="text-white hover:text-gray-200 focus:outline-none bg-black/30 p-2 rounded-full"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>
              <div className="absolute bottom-4 left-6">
                <span className="inline-block bg-amber-500 text-xs font-semibold px-2 py-1 rounded-full mb-2 text-white">
                  {card.category}
                </span>
                <h2 className="text-3xl font-bold text-white">{card.issuer} {card.name}</h2>
              </div>
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center">
                  <CreditCardIcon size={20} className="mr-2 text-navy-600" />
                  Card Details
                </h3>
                
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-500">Annual Fee</p>
                    <p className="font-medium">{card.annualFee === 0 ? 'No annual fee' : `$${card.annualFee}`}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Intro APR</p>
                    <p className="font-medium">{card.introAPR}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Regular APR</p>
                    <p className="font-medium">{card.regularAPR}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Foreign Transaction Fee</p>
                    <p className="font-medium">{card.foreignTransactionFee}</p>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Credit Score Required</p>
                    <p className="font-medium">{card.creditScoreRequired}</p>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center">
                  <Award size={20} className="mr-2 text-navy-600" />
                  Rewards & Benefits
                </h3>
                
                <div className="space-y-3">
                  <div>
                    <p className="text-sm text-gray-500">Rewards Rate</p>
                    <p className="font-medium">{card.rewardsRate}</p>
                  </div>
                  
                  {card.signupBonus && (
                    <div className="bg-amber-50 p-3 rounded-md border border-amber-100">
                      <p className="text-sm text-gray-700 font-medium">Sign-up Bonus</p>
                      <p className="font-medium text-amber-700">{card.signupBonus}</p>
                    </div>
                  )}
                  
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Card Perks</p>
                    <ul className="list-disc pl-5 space-y-1">
                      {card.perks.map((perk, index) => (
                        <li key={index} className="text-sm">{perk}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-8 space-y-4">
              <button
                onClick={() => onAddToComparison(card)}
                className={`w-full py-3 rounded-lg font-medium transition-colors ${
                  isInComparison 
                    ? 'bg-gray-200 text-gray-600 cursor-not-allowed' 
                    : 'bg-amber-500 text-white hover:bg-amber-600'
                }`}
                disabled={isInComparison}
              >
                {isInComparison ? 'Added to Comparison' : 'Add to Comparison'}
              </button>
              
              <a 
                href="#" 
                className="block w-full py-3 bg-navy-600 text-white rounded-lg font-medium text-center hover:bg-navy-700 transition-colors"
              >
                Apply Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardDetailModal;