import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <div className="relative h-[600px] flex items-center">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-navy-800/90 to-navy-600/80"></div>
        <img 
          src="https://images.pexels.com/photos/3943746/pexels-photo-3943746.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
          alt="Credit cards background" 
          className="w-full h-full object-cover"
        />
      </div>
      
      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
            Find Your Perfect <span className="text-amber-400">Credit Card</span> Match
          </h1>
          
          <p className="text-lg text-gray-100 mb-8">
            Compare features, rewards, and benefits to discover the ideal card for your lifestyle and financial goals.
          </p>
          
          <div className="bg-white p-6 rounded-xl shadow-lg">
            <h2 className="text-xl font-semibold text-navy-700 mb-4">What matters most to you?</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
              <button className="py-3 px-4 bg-amber-500 text-white rounded-lg font-medium hover:bg-amber-600 transition-colors">
                Cash Back
              </button>
              <button className="py-3 px-4 bg-white border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors">
                Travel
              </button>
              <button className="py-3 px-4 bg-white border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors">
                No Annual Fee
              </button>
              <button className="py-3 px-4 bg-white border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors">
                Low Interest
              </button>
            </div>
            
            <div className="flex">
              <a 
                href="#cards" 
                className="block w-full py-3 bg-navy-600 text-white rounded-lg font-medium text-center hover:bg-navy-700 transition-colors"
              >
                Find My Cards
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;