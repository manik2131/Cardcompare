export interface CreditCard {
  id: string;
  name: string;
  issuer: string;
  imageUrl: string;
  annualFee: number;
  introAPR: string;
  regularAPR: string;
  rewardsRate: string;
  creditScoreRequired: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  perks: string[];
  signupBonus?: string;
  foreignTransactionFee: string;
  category: 'Cashback' | 'Travel' | 'Business' | 'Student' | 'Secured';
}

export interface FilterOptions {
  annualFee: 'all' | 'no-fee' | 'under-100' | '100-plus';
  creditScore: 'all' | 'excellent' | 'good' | 'fair' | 'poor';
  category: 'all' | 'cashback' | 'travel' | 'business' | 'student' | 'secured';
}

export interface SortOption {
  label: string;
  value: 'annualFee' | 'rewardsRate' | 'regularAPR';
  direction: 'asc' | 'desc';
}

export interface BankStatement {
  id: string;
  fileName: string;
  fileSize: number;
  uploadDate: Date;
  month: string;
  year: number;
  status: 'processing' | 'completed' | 'error';
}

export interface SpendingAnalysis {
  totalSpending: number;
  categories: {
    dining: number;
    groceries: number;
    gas: number;
    travel: number;
    shopping: number;
    utilities: number;
    other: number;
  };
  averageMonthlySpend: number;
  topCategories: string[];
  recommendedCards: string[];
}