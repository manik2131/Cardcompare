import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import HeroSection from '../components/HeroSection';
import Footer from '../components/Footer';
import CreditCardItem from '../components/CreditCardItem';
import FilterSort from '../components/FilterSort';
import CardDetailModal from '../components/CardDetailModal';
import CardComparisonModal from '../components/CardComparisonModal';
import BankStatementUpload from '../components/BankStatementUpload';
import { creditCards, getSortedCards, filterCards } from '../data/creditCards';
import { CreditCard, FilterOptions, SortOption, SpendingAnalysis } from '../types';

const HomePage: React.FC = () => {
  const [filters, setFilters] = useState<FilterOptions>({
    annualFee: 'all',
    creditScore: 'all',
    category: 'all'
  });
  
  const [sortOption, setSortOption] = useState<SortOption>({
    label: 'Annual Fee (Low to High)',
    value: 'annualFee',
    direction: 'asc'
  });
  
  const [filteredCards, setFilteredCards] = useState<CreditCard[]>(creditCards);
  const [selectedCard, setSelectedCard] = useState<CreditCard | null>(null);
  const [comparisonCards, setComparisonCards] = useState<CreditCard[]>([]);
  const [showComparisonModal, setShowComparisonModal] = useState(false);
  const [spendingAnalysis, setSpendingAnalysis] = useState<SpendingAnalysis | null>(null);
  const [recommendedCardIds, setRecommendedCardIds] = useState<string[]>([]);
  
  useEffect(() => {
    const filtered = filterCards(creditCards, filters);
    const sorted = getSortedCards(filtered, sortOption.value, sortOption.direction);
    setFilteredCards(sorted);
  }, [filters, sortOption]);
  
  const handleCardClick = (card: CreditCard) => {
    setSelectedCard(card);
  };
  
  const handleCloseCardDetail = () => {
    setSelectedCard(null);
  };
  
  const handleAddToComparison = (card: CreditCard) => {
    if (comparisonCards.length < 3 && !comparisonCards.some(c => c.id === card.id)) {
      setComparisonCards([...comparisonCards, card]);
    }
    setSelectedCard(null);
  };
  
  const handleRemoveFromComparison = (cardId: string) => {
    setComparisonCards(comparisonCards.filter(card => card.id !== cardId));
  };
  
  const isInComparison = (cardId: string) => {
    return comparisonCards.some(card => card.id === cardId);
  };
  
  const handleAnalysisComplete = (analysis: SpendingAnalysis) => {
    setSpendingAnalysis(analysis);
    setRecommendedCardIds(analysis.recommendedCards);
  };
  
  const isRecommended = (cardId: string) => {
    return recommendedCardIds.includes(cardId);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <HeroSection />
        
        <section id="cards" className="bg-gray-100 py-16">
          <div className="container mx-auto px-4">
            <BankStatementUpload onAnalysisComplete={handleAnalysisComplete} />
            
            <div className="mb-8">
              <h2 className="text-3xl font-bold text-navy-700 mb-2">Compare Credit Cards</h2>
              <p className="text-gray-600">
                Find the perfect card for your spending habits and financial goals.
              </p>
            </div>
            
            <FilterSort 
              filters={filters} 
              setFilters={setFilters} 
              sortOption={sortOption}
              setSortOption={setSortOption}
            />
            
            {/* Comparison Bar */}
            {comparisonCards.length > 0 && (
              <div className="sticky top-20 z-30 bg-white shadow-md rounded-lg p-4 mb-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-navy-700 font-medium mr-2">
                      {comparisonCards.length} {comparisonCards.length === 1 ? 'Card' : 'Cards'} Selected
                    </span>
                    <div className="flex space-x-2">
                      {comparisonCards.map(card => (
                        <div key={card.id} className="flex items-center bg-gray-100 px-2 py-1 rounded">
                          <span className="text-sm">{card.issuer} {card.name}</span>
                          <button 
                            onClick={() => handleRemoveFromComparison(card.id)}
                            className="ml-1 text-gray-500 hover:text-red-500"
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <button
                    onClick={() => setShowComparisonModal(true)}
                    className="bg-amber-500 hover:bg-amber-600 text-white py-2 px-4 rounded transition-colors"
                    disabled={comparisonCards.length < 2}
                  >
                    Compare Now
                  </button>
                </div>
              </div>
            )}
            
            {/* Card Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCards.map(card => (
                <CreditCardItem 
                  key={card.id} 
                  card={card} 
                  onClick={handleCardClick}
                  isSelected={isInComparison(card.id)}
                  isRecommended={isRecommended(card.id)}
                />
              ))}
            </div>
            
            {filteredCards.length === 0 && (
              <div className="text-center py-12">
                <p className="text-lg text-gray-600">No cards match your current filters.</p>
                <button
                  onClick={() => {
                    setFilters({
                      annualFee: 'all',
                      creditScore: 'all',
                      category: 'all'
                    });
                    setSortOption({
                      label: 'Annual Fee (Low to High)',
                      value: 'annualFee',
                      direction: 'asc'
                    });
                  }}
                  className="mt-4 text-navy-600 font-medium underline"
                >
                  Reset Filters
                </button>
              </div>
            )}
          </div>
        </section>
        
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="mb-8 text-center">
              <h2 className="text-3xl font-bold text-navy-700 mb-2">Why Choose CardCompare</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                We help you find the perfect credit card for your unique situation with our comprehensive comparison tools.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center p-6 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-navy-700 mb-2">Easy Comparison</h3>
                <p className="text-gray-600">
                  Side-by-side comparisons make it easy to evaluate different credit card options at a glance.
                </p>
              </div>
              
              <div className="text-center p-6 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-navy-700 mb-2">Unbiased Reviews</h3>
                <p className="text-gray-600">
                  Our comprehensive card evaluations help you understand the real benefits and drawbacks.
                </p>
              </div>
              
              <div className="text-center p-6 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <svg className="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-navy-700 mb-2">Rewards Calculator</h3>
                <p className="text-gray-600">
                  Calculate potential rewards based on your spending habits to find the most rewarding card.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
      
      {selectedCard && (
        <CardDetailModal 
          card={selectedCard} 
          onClose={handleCloseCardDetail} 
          onAddToComparison={handleAddToComparison}
          isInComparison={isInComparison(selectedCard.id)}
        />
      )}
      
      {showComparisonModal && (
        <CardComparisonModal 
          cards={comparisonCards} 
          onClose={() => setShowComparisonModal(false)} 
        />
      )}
    </div>
  );
};

export default HomePage;