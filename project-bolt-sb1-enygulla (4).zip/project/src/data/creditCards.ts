import { CreditCard } from '../types';

export const creditCards: CreditCard[] = [
  {
    id: 'Credit-Card',
    name: 'Emeralde',
    issuer: 'ICICI',
    imageUrl: 'https://images.pexels.com/photos/6214478/pexels-photo-6214478.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 95,
    introAPR: '0% for 12 months',
    regularAPR: '18.99% - 25.99%',
    rewardsRate: '2x points on travel and dining',
    creditScoreRequired: 'Excellent',
    perks: [
      '60,000 bonus points after spending $4,000 in first 3 months',
      '25% more value when redeeming for travel through Chase portal',
      'Transfer points to travel partners',
      'No foreign transaction fees'
    ],
    signupBonus: '60,000 bonus points',
    foreignTransactionFee: '0%',
    category: 'Travel'
  },
  {
    id: 'amex-platinum',
    name: 'Platinum Card',
    issuer: 'American Express',
    imageUrl: 'https://images.pexels.com/photos/6214394/pexels-photo-6214394.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 695,
    introAPR: 'N/A',
    regularAPR: '18.99% - 25.99%',
    rewardsRate: '5x points on flights and hotels',
    creditScoreRequired: 'Excellent',
    perks: [
      '$200 airline fee credit',
      '$200 Uber credit ($15/month, $20 in December)',
      'Access to Centurion Lounges',
      'Global Entry or TSA PreCheck credit'
    ],
    signupBonus: '100,000 Membership Rewards points',
    foreignTransactionFee: '0%',
    category: 'Travel'
  },
  {
    id: 'citi-double-cash',
    name: 'Double Cash',
    issuer: 'Citi',
    imageUrl: 'https://images.pexels.com/photos/6214455/pexels-photo-6214455.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 0,
    introAPR: '0% for 18 months',
    regularAPR: '16.99% - 26.99%',
    rewardsRate: '2% cash back on all purchases',
    creditScoreRequired: 'Good',
    perks: [
      '1% when you buy, 1% when you pay',
      'No categories to track',
      'No rewards expiration'
    ],
    foreignTransactionFee: '3%',
    category: 'Cashback'
  },
  {
    id: 'Credit',
    name: 'Atlas',
    issuer: 'Axis',
    imageUrl: 'https://images.pexels.com/photos/6214807/pexels-photo-6214807.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 0,
    introAPR: '0% for 14 months',
    regularAPR: '14.99% - 25.99%',
    rewardsRate: '5% cash back on rotating categories',
    creditScoreRequired: 'Good',
    perks: [
      'Cashback match for first year',
      'No foreign transaction fees',
      'Free FICO score'
    ],
    signupBonus: 'Cashback match for first year',
    foreignTransactionFee: '0%',
    category: 'Cashback'
  },
  {
    id: 'Black-metal',
    name: 'DinerClub',
    issuer: 'HDFC',
    imageUrl: 'https://images.pexels.com/photos/6214944/pexels-photo-6214944.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 95,
    introAPR: 'N/A',
    regularAPR: '17.99% - 25.99%',
    rewardsRate: '2x miles on all purchases',
    creditScoreRequired: 'Excellent',
    perks: [
      '60,000 bonus miles after spending $3,000 in first 3 months',
      'Global Entry or TSA PreCheck credit',
      'No foreign transaction fees'
    ],
    signupBonus: '60,000 bonus miles',
    foreignTransactionFee: '0%',
    category: 'Travel'
  },
  {
    id: 'chase-freedom-unlimited',
    name: 'Freedom Unlimited',
    issuer: 'Chase',
    imageUrl: 'https://images.pexels.com/photos/6214949/pexels-photo-6214949.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 0,
    introAPR: '0% for 15 months',
    regularAPR: '17.99% - 26.74%',
    rewardsRate: '1.5% cash back on all purchases',
    creditScoreRequired: 'Good',
    perks: [
      '3% cash back on dining',
      '3% cash back on drugstore purchases',
      '5% cash back on travel purchased through Chase'
    ],
    signupBonus: '$200 bonus after spending $500 in first 3 months',
    foreignTransactionFee: '3%',
    category: 'Cashback'
  },
  {
    id: 'capital-one-quicksilver',
    name: 'Quicksilver',
    issuer: 'Capital One',
    imageUrl: 'https://images.pexels.com/photos/6214531/pexels-photo-6214531.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 0,
    introAPR: '0% for 15 months',
    regularAPR: '16.99% - 26.99%',
    rewardsRate: '1.5% cash back on all purchases',
    creditScoreRequired: 'Good',
    perks: [
      'No foreign transaction fees',
      'Extended warranty protection',
      'Travel accident insurance'
    ],
    signupBonus: '$200 cash bonus after spending $500 in first 3 months',
    foreignTransactionFee: '0%',
    category: 'Cashback'
  },
  {
    id: 'discover-it-secured',
    name: 'Discover it Secured',
    issuer: 'Discover',
    imageUrl: 'https://images.pexels.com/photos/6214476/pexels-photo-6214476.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    annualFee: 0,
    introAPR: 'N/A',
    regularAPR: '24.99%',
    rewardsRate: '2% cash back at gas stations and restaurants',
    creditScoreRequired: 'Poor',
    perks: [
      'No annual fee',
      'Cashback match for first year',
      'Path to unsecured credit'
    ],
    foreignTransactionFee: '0%',
    category: 'Secured'
  }
];

export const getSortedCards = (
  cards: CreditCard[], 
  sortBy: 'annualFee' | 'rewardsRate' | 'regularAPR', 
  direction: 'asc' | 'desc'
): CreditCard[] => {
  return [...cards].sort((a, b) => {
    if (sortBy === 'annualFee') {
      return direction === 'asc' 
        ? a.annualFee - b.annualFee
        : b.annualFee - a.annualFee;
    }
    
    if (sortBy === 'regularAPR') {
      const getAPRValue = (apr: string) => {
        const match = apr.match(/(\d+\.\d+)/);
        return match ? parseFloat(match[0]) : 0;
      };
      
      const aValue = getAPRValue(a.regularAPR);
      const bValue = getAPRValue(b.regularAPR);
      
      return direction === 'asc' 
        ? aValue - bValue
        : bValue - aValue;
    }
    
    // Default for rewardsRate and other cases
    return direction === 'asc'
      ? a.name.localeCompare(b.name)
      : b.name.localeCompare(a.name);
  });
};

export const filterCards = (
  cards: CreditCard[],
  filters: FilterOptions
): CreditCard[] => {
  return cards.filter(card => {
    // Filter by annual fee
    if (filters.annualFee !== 'all') {
      if (filters.annualFee === 'no-fee' && card.annualFee !== 0) return false;
      if (filters.annualFee === 'under-100' && (card.annualFee === 0 || card.annualFee >= 100)) return false;
      if (filters.annualFee === '100-plus' && card.annualFee < 100) return false;
    }
    
    // Filter by credit score
    if (filters.creditScore !== 'all') {
      const scoreMap: Record<string, string> = {
        'excellent': 'Excellent',
        'good': 'Good',
        'fair': 'Fair',
        'poor': 'Poor'
      };
      
      if (card.creditScoreRequired !== scoreMap[filters.creditScore]) return false;
    }
    
    // Filter by category
    if (filters.category !== 'all') {
      const categoryMap: Record<string, string> = {
        'cashback': 'Cashback',
        'travel': 'Travel',
        'business': 'Business',
        'student': 'Student',
        'secured': 'Secured'
      };
      
      if (card.category !== categoryMap[filters.category]) return false;
    }
    
    return true;
  });
};