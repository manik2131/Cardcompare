/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'navy': {
          '50': '#f0f3f9',
          '100': '#dce4f0',
          '200': '#bfcee4',
          '300': '#94afd0',
          '400': '#6689bb',
          '500': '#476ca7',
          '600': '#395389',
          '700': '#2f426f',
          '800': '#0A2540', // Primary navy
          '900': '#1d2745',
          '950': '#121830',
        },
        'amber': {
          '50': '#fffbeb',
          '100': '#fef3c7',
          '200': '#fde68a',
          '300': '#fcd34d',
          '400': '#fbbf24',
          '500': '#FFB236', // Accent gold
          '600': '#d97706',
          '700': '#b45309',
          '800': '#92400e',
          '900': '#78350f',
          '950': '#451a03',
        },
      },
    },
  },
  plugins: [],
};